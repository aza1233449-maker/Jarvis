package com.jarvis.asistente

import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Cerebro con inteligencia artificial: usa la API de Gemini con la clave del propio usuario. */
object Llm {
    class Result(val speech: String, val actions: List<Pair<String, JSONObject>>)

    private class Raw(val code: Int, val text: String, val offline: Boolean)

    private val history = ArrayList<Pair<String, String>>()
    private val fallbacks = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-3.6-flash")

    fun clear() {
        synchronized(history) { history.clear() }
    }

    private fun systemPrompt(ctx: Context): String {
        val now = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es", "PE")).format(Date())
        var bat = -1
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
        }
        val who = sir()
        return (
            "Eres JARVIS, el asistente personal de inteligencia artificial de Tony Stark, ahora al servicio de " + who + ". " +
                "Hablas español latino con un tono elegante, sereno, eficiente y con un toque de ingenio seco y educado, como el JARVIS de las películas. " +
                "Llamas al usuario \"" + who + "\". " +
                "Tus respuestas se leen en voz alta: máximo 2 o 3 frases cortas, sin markdown, sin listas, sin emojis y sin direcciones web. " +
                "Si dependes de datos en tiempo real (clima, noticias, precios, resultados deportivos) y no los tienes, dilo con honestidad y ofrece buscarlo con la acción search. Nunca inventes datos. " +
                "Fecha y hora actuales: " + now + ". Batería del teléfono: " + (if (bat >= 0) "$bat%" else "desconocida") + ". " +
                "Responde SIEMPRE con un único objeto JSON con esta forma: {\"speech\":\"texto que dirás\",\"actions\":[{\"name\":\"...\",\"args\":{...}}]}. \"actions\" puede ir vacío. " +
                "Acciones disponibles: " +
                "flashlight {\"on\":true|false}; " +
                "volume {\"dir\":\"up|down|mute|unmute|max\"} o {\"percent\":0-100}; " +
                "media {\"cmd\":\"play_pause|next|previous|stop\"}; " +
                "timer {\"seconds\":número,\"label\":\"texto\"}; " +
                "alarm {\"hour\":0-23,\"minute\":0-59,\"label\":\"texto\"}; " +
                "call {\"name\":\"contacto\"} o {\"number\":\"dígitos\"}; " +
                "sms {\"name\":\"contacto\",\"number\":\"dígitos\",\"text\":\"mensaje\"} (el sistema pide confirmación); " +
                "whatsapp_message {\"name\":\"contacto\",\"number\":\"dígitos\",\"text\":\"mensaje\"} (abre el chat con el texto escrito); " +
                "reply_message {\"name\":\"quien escribió\",\"text\":\"respuesta\",\"app\":\"whatsapp|instagram\"} (responde a un mensaje recibido; el sistema pide confirmación); " +
                "read_messages {\"name\":\"opcional\"} (lee los mensajes nuevos de WhatsApp e Instagram; no los inventes jamás); " +
                "open_app {\"name\":\"nombre de la app\"}; " +
                "navigate {\"query\":\"destino\"}; " +
                "search {\"query\":\"texto\"}; " +
                "youtube {\"query\":\"texto\"}; " +
                "spotify {\"query\":\"texto\"}; " +
                "settings {\"target\":\"wifi|bluetooth|sound|display|battery|location\"}. " +
                "Usa acciones solo cuando el usuario lo pida. En speech confirma brevemente lo que haces. " +
                "Para sms y reply_message nunca digas que ya se envió; di que vas a prepararlo. " +
                "Si el usuario pide algo que no puedes hacer, explícalo con franqueza y propón una alternativa."
            )
    }

    private fun body(ctx: Context, text: String): String {
        val b = JSONObject()
        b.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(ctx)))))
        val contents = JSONArray()
        synchronized(history) {
            for ((role, t) in history.takeLast(12)) {
                contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        b.put("contents", contents)
        b.put(
            "generationConfig",
            JSONObject().put("responseMimeType", "application/json").put("temperature", 0.7).put("maxOutputTokens", 2048)
        )
        return b.toString()
    }

    private fun post(model: String, key: String, body: String): Raw {
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            c.disconnect()
            Raw(code, txt, false)
        } catch (e: Exception) {
            Raw(-1, "", true)
        }
    }

    /** Bloqueante: llamar desde un hilo secundario. */
    fun ask(ctx: Context, text: String): Result {
        val key = Prefs.apiKey.trim()
        if (key.isEmpty()) {
            return Result("Aún no tengo configurada mi inteligencia, ${sir()}. Pegue su clave gratuita en Ajustes.", emptyList())
        }
        val payload = body(ctx, text)
        val models = ArrayList<String>()
        val chosen = Prefs.model.trim()
        models.add(if (chosen.isEmpty()) fallbacks[0] else chosen)
        for (m in fallbacks) if (!models.contains(m)) models.add(m)

        var lastMsg = "No pude consultar mi inteligencia, ${sir()}."
        for (m in models) {
            val raw = post(m, key, payload)
            if (raw.offline) {
                return Result("No tengo conexión a internet, ${sir()}.", emptyList())
            }
            val code = raw.code
            if (code in 200..299) {
                val r = parse(raw.text)
                if (r != null) {
                    Prefs.model = m
                    synchronized(history) {
                        history.add(Pair("user", text))
                        history.add(Pair("model", r.speech))
                        while (history.size > 24) history.removeAt(0)
                    }
                    return r
                }
                lastMsg = "No pude entender la respuesta de mi inteligencia, ${sir()}."
                continue
            }
            val low = raw.text.lowercase()
            if (code == 400 && (low.contains("api key") || low.contains("api_key"))) {
                return Result("Su clave de Google no es válida, ${sir()}. Revísela en Ajustes.", emptyList())
            }
            if (code == 401 || code == 403) {
                return Result("Google rechazó mi clave, ${sir()}. Revise que la copió completa en Ajustes.", emptyList())
            }
            if (code == 404 || code == 429 || (code == 400 && low.contains("model"))) {
                lastMsg = if (code == 429) {
                    "Alcancé el límite gratuito de consultas, ${sir()}. Inténtelo de nuevo en un minuto."
                } else {
                    "El modelo de inteligencia configurado no está disponible, ${sir()}."
                }
                continue
            }
            if (code >= 500) {
                return Result("Los servidores de Google están ocupados, ${sir()}. Intente de nuevo en un momento.", emptyList())
            }
            return Result("Mi inteligencia devolvió el error $code, ${sir()}.", emptyList())
        }
        return Result(lastMsg, emptyList())
    }

    private fun parse(raw: String): Result? {
        try {
            val j = JSONObject(raw)
            val cands = j.optJSONArray("candidates") ?: return null
            val first = cands.optJSONObject(0) ?: return null
            val parts = first.optJSONObject("content")?.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text", ""))
            }
            var out = sb.toString().trim()
            if (out.isEmpty()) return null
            if (out.startsWith("```")) {
                out = out.substringAfter("\n", out).trim()
                if (out.endsWith("```")) out = out.removeSuffix("```").trim()
            }
            var speech = out
            val acts = ArrayList<Pair<String, JSONObject>>()
            try {
                val o = JSONObject(out)
                speech = o.optString("speech", "").trim()
                val arr = o.optJSONArray("actions")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val a = arr.optJSONObject(i) ?: continue
                        val name = a.optString("name", "")
                        if (name.isEmpty()) continue
                        acts.add(Pair(name, a.optJSONObject("args") ?: JSONObject()))
                    }
                }
            } catch (e: Exception) {
                // no era JSON: se usa el texto tal cual
            }
            if (speech.isEmpty()) speech = if (acts.isEmpty()) "No supe qué responder, ${sir()}." else "Hecho, ${sir()}."
            return Result(speech, acts)
        } catch (e: Exception) {
            return null
        }
    }
}
