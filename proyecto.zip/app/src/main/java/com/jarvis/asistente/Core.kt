package com.jarvis.asistente

import android.app.Application
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale

/* ------------------------------------------------------------------ */
/*  Aplicación y preferencias                                          */
/* ------------------------------------------------------------------ */

class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Engine.init(this)
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    }

    var pitch: Float
        get() = sp.getFloat("pitch", 0.7f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }

    var rate: Float
        get() = sp.getFloat("rate", 0.94f)
        set(v) { sp.edit().putFloat("rate", v).apply() }

    var voiceName: String
        get() = sp.getString("voice", "") ?: ""
        set(v) { sp.edit().putString("voice", v).apply() }

    var userName: String
        get() = sp.getString("user", "") ?: ""
        set(v) { sp.edit().putString("user", v).apply() }

    var announce: Boolean
        get() = sp.getBoolean("announce", false)
        set(v) { sp.edit().putBoolean("announce", v).apply() }

    var continuous: Boolean
        get() = sp.getBoolean("continuous", false)
        set(v) { sp.edit().putBoolean("continuous", v).apply() }

    var apiKey: String
        get() = sp.getString("apikey", "") ?: ""
        set(v) { sp.edit().putString("apikey", v).apply() }

    var model: String
        get() = sp.getString("model", "gemini-3.5-flash-lite") ?: "gemini-3.5-flash-lite"
        set(v) { sp.edit().putString("model", v).apply() }
}

fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

fun sir(): String = Prefs.userName.ifEmpty { "señor" }

fun short(s: String): String = if (s.length > 140) s.take(140) + "…" else s

/* ------------------------------------------------------------------ */
/*  Bandeja de mensajes (solo en memoria)                              */
/* ------------------------------------------------------------------ */

class Msg(
    val id: String,
    val app: String,
    val sender: String,
    val text: String,
    val time: Long,
    var read: Boolean = false
)

class ReplyTarget(
    val pkg: String,
    val app: String,
    val sender: String,
    val action: Notification.Action,
    val input: RemoteInput
)

object Inbox {
    private val lock = Any()
    private val msgs = ArrayList<Msg>()
    private val seen = HashSet<String>()
    private val targets = LinkedHashMap<String, ReplyTarget>()

    @Volatile
    var connected = false

    fun add(m: Msg): Boolean {
        synchronized(lock) {
            if (!seen.add(m.id)) return false
            msgs.add(m)
            while (msgs.size > 80) msgs.removeAt(0)
            if (seen.size > 600) seen.clear()
        }
        return true
    }

    fun setTarget(t: ReplyTarget) {
        synchronized(lock) {
            val k = t.pkg + "|" + norm(t.sender)
            targets.remove(k)
            targets[k] = t
        }
    }

    /** Conversaciones a las que se puede responder, la más reciente primero. */
    fun targetList(): List<ReplyTarget> {
        synchronized(lock) { return targets.values.toList().reversed() }
    }

    fun findTarget(name: String?, app: String?): ReplyTarget? {
        val all = targetList().filter { app == null || norm(it.app) == app }
        if (name.isNullOrBlank()) return all.firstOrNull()
        val n = norm(name).trim()
        return all.firstOrNull { norm(it.sender).trim() == n }
            ?: all.firstOrNull { val s = norm(it.sender).trim(); s.contains(n) || n.contains(s) }
    }

    fun unread(): List<Msg> {
        synchronized(lock) { return msgs.filter { !it.read } }
    }

    fun latestFrom(name: String): Msg? {
        val n = norm(name).trim()
        synchronized(lock) {
            return msgs.lastOrNull { val s = norm(it.sender).trim(); s == n || s.contains(n) }
        }
    }

    fun markRead(list: List<Msg>) {
        synchronized(lock) { list.forEach { it.read = true } }
    }

    fun total(): Int {
        synchronized(lock) { return msgs.size }
    }

    fun clear() {
        synchronized(lock) {
            msgs.clear()
            seen.clear()
            targets.clear()
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Lector de notificaciones de WhatsApp e Instagram                   */
/* ------------------------------------------------------------------ */

class NotificationService : NotificationListenerService() {

    override fun onCreate() {
        super.onCreate()
        Speaker.init(applicationContext)
    }

    override fun onListenerConnected() {
        Inbox.connected = true
        try {
            val active = activeNotifications
            if (active != null) {
                for (sbn in active) handle(sbn, false)
            }
        } catch (e: Exception) {
            // si el sistema no deja leer las activas, se ignoran
        }
    }

    override fun onListenerDisconnected() {
        Inbox.connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) handle(sbn, true)
    }

    private fun handle(sbn: StatusBarNotification, announce: Boolean) {
        val pkg = sbn.packageName ?: return
        val app = when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
            "com.instagram.android" -> "Instagram"
            else -> return
        }
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (sbn.isOngoing) return
        val extras = n.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        if (title.isEmpty()) return
        val sender = title.replace(Regex("\\s*\\(\\d+[^)]*\\)\\s*$"), "").trim()

        var action: Notification.Action? = null
        var input: RemoteInput? = null
        val acts = n.actions
        if (acts != null) {
            for (a in acts) {
                val inputs = a.remoteInputs
                if (inputs != null && inputs.isNotEmpty()) {
                    action = a
                    input = inputs[0]
                    break
                }
            }
        }
        if (app == "Instagram" && input == null && n.category != Notification.CATEGORY_MESSAGE) return

        val found = ArrayList<Pair<String, Long>>()
        @Suppress("DEPRECATION")
        val arr = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null) {
            for (p in arr) {
                val b = (p as? Bundle) ?: continue
                val t = b.getCharSequence("text")?.toString()?.trim().orEmpty()
                if (t.isEmpty()) continue
                val who = b.getCharSequence("sender")?.toString()?.trim().orEmpty()
                if (norm(who) in setOf("tu", "you", "yo", "me")) continue
                val line = if (who.isNotEmpty() && norm(who) != norm(sender)) "$who: $t" else t
                found.add(Pair(line, b.getLong("time", sbn.postTime)))
            }
        }
        if (found.isEmpty()) {
            val t = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) found.add(Pair(t, sbn.postTime))
        }
        if (found.isEmpty()) return

        val act = action
        val inp = input
        if (act != null && inp != null) Inbox.setTarget(ReplyTarget(pkg, app, sender, act, inp))

        for ((text, time) in found) {
            val low = norm(text)
            if (low.startsWith("verificando mensajes") || low.startsWith("checking for new messages")) continue
            val id = pkg + "|" + sender + "|" + time + "|" + text.hashCode()
            val isNew = Inbox.add(Msg(id, app, sender, text, time))
            if (isNew && announce && Prefs.announce) {
                Engine.announce("Mensaje de $sender por $app: ${short(text)}")
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Voz                                                                */
/* ------------------------------------------------------------------ */

object Speaker : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private val queue = ArrayList<Pair<String, (() -> Unit)?>>()
    private val main = Handler(Looper.getMainLooper())
    private var done: (() -> Unit)? = null

    private val male = Regex(
        "male|masculin|daniel|jorge|diego|juan|carlos|pablo|enrique|miguel|alvaro|raul|alonso|mateo|andres|santiago",
        RegexOption.IGNORE_CASE
    )
    private val female = Regex(
        "female|femenin|monica|paulina|helena|laura|sabina|lucia|elena|sofia|camila|valeria|maria|carmen",
        RegexOption.IGNORE_CASE
    )

    fun init(ctx: Context) {
        if (tts == null) tts = TextToSpeech(ctx.applicationContext, this)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            failed = true
            val lost = ArrayList(queue)
            queue.clear()
            for ((_, cb) in lost) if (cb != null) main.post { cb() }
            return
        }
        ready = true
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                finish()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish()
            }
        })
        applyVoice()
        val pending = ArrayList(queue)
        queue.clear()
        for ((text, cb) in pending) speakNow(text, cb)
    }

    private fun finish() {
        val cb = done
        done = null
        if (cb != null) main.post { cb() }
    }

    fun voices(): List<Voice> {
        val t = tts ?: return emptyList()
        return try {
            (t.voices ?: emptySet<Voice>()).filter { it.locale.language == "es" }.sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun pickVoice(): Voice? {
        val vs = voices()
        val saved = Prefs.voiceName
        if (saved.isNotEmpty()) {
            val v = vs.firstOrNull { it.name == saved }
            if (v != null) return v
        }
        var best: Voice? = null
        var bestScore = Int.MIN_VALUE
        for (v in vs) {
            var s = 0
            when (v.locale.country.uppercase()) {
                "MX" -> s += 30
                "PE" -> s += 28
                "US" -> s += 25
                "419" -> s += 25
                "ES" -> s += 10
            }
            if (male.containsMatchIn(v.name)) s += 40
            if (female.containsMatchIn(v.name)) s -= 40
            if (!v.isNetworkConnectionRequired) s += 5
            if (s > bestScore) {
                bestScore = s
                best = v
            }
        }
        return best
    }

    fun applyVoice() {
        val t = tts ?: return
        val locales = listOf(Locale("es", "MX"), Locale("es", "US"), Locale("es", "ES"), Locale("es"))
        for (l in locales) {
            val r = t.setLanguage(l)
            if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) break
        }
        val v = pickVoice()
        if (v != null) t.setVoice(v)
        t.setPitch(Prefs.pitch)
        t.setSpeechRate(Prefs.rate)
    }

    /** Pasa a la siguiente voz en español instalada y devuelve su nombre. */
    fun nextVoice(): String {
        val vs = voices()
        if (vs.isEmpty()) return ""
        val idx = vs.indexOfFirst { it.name == Prefs.voiceName }
        val v = vs[(idx + 1) % vs.size]
        Prefs.voiceName = v.name
        applyVoice()
        return v.name + " (" + v.locale.toString() + ")"
    }

    fun speak(text: String, onDone: (() -> Unit)?) {
        if (failed) {
            if (onDone != null) main.post { onDone() }
            return
        }
        if (!ready) {
            queue.add(Pair(text, onDone))
            return
        }
        speakNow(text, onDone)
    }

    private fun speakNow(text: String, onDone: (() -> Unit)?) {
        val t = tts ?: return
        t.setPitch(Prefs.pitch)
        t.setSpeechRate(Prefs.rate)
        done = onDone
        val clean = text.replace(Regex("[*_#`>~]"), " ")
        val r = t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        if (r != TextToSpeech.SUCCESS) finish()
    }

    fun stop() {
        done = null
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Cerebro: interpreta las órdenes (sin internet, sin IA externa)     */
/* ------------------------------------------------------------------ */

object Brain {
    private class Pending(val run: () -> String)

    private var pending: Pending? = null

    fun hasPending(): Boolean = pending != null

    private val yes = Regex("^(si|claro|envialo|enviala|confirmo|confirma|dale|adelante|ok|okey|correcto|afirmativo|mandalo|mandala)\\b")
    private val no = Regex("^(no|cancela|cancelalo|cancelar|mejor no|olvidalo|detente)\\b")

    private val replyRe = Regex("^(?:responde|respondele|responder|contesta|contestale|contestar|dile|escribele)\\s+(?:a\\s+)?(.+)$")
    private val leadRe = Regex("^(?:(?:que|diciendo)\\b|:)\\s*")
    private val splitRe = Regex("\\s+que\\s+|\\s*:\\s*|\\s+diciendo\\s+")
    private val stripRe = Regex("^[\\s:,]*(?:(?:por|en|via)\\s+(whatsapp|wasap|wsp|instagram|insta|ig)\\b[\\s:,]*)?(?:(?:que|diciendo)\\s+)?")

    private val fromRe = Regex("^(?:que dice|que dijo|que me escribio|lee lo de|leeme lo de|lee el ultimo mensaje de|ultimo mensaje de|mensaje de|lee el mensaje de)\\s+(.+)$")
    private val summaryRe = Regex("\\b(mensajes? (?:nuevos?|sin leer|pendientes?)|tengo mensajes|que mensajes|mis mensajes|revisa mis mensajes|lee mis mensajes|leeme mis mensajes|alguien me escribio|me escribio alguien|que me han escrito)\\b")
    private val openRe = Regex("^(?:abre|abreme|abrir|lanza|inicia)\\s+(?:el |la |mi )?(?:app de |aplicacion de )?(whatsapp|wasap|wsp|instagram|insta)\\b")

    fun confirm(say: String, run: () -> String): String {
        pending = Pending(run)
        return "$say ¿Lo confirmo?"
    }

    fun local(ctx: Context, orig: String): String? {
        val o = orig.trim()
        if (o.isEmpty()) return "No le escuché, ${sir()}."
        val low = norm(o).replace(Regex("[¿?¡!]"), " ")
        val t = low.trim()

        val p = pending
        if (p != null) {
            pending = null
            if (yes.containsMatchIn(t)) return p.run()
            if (no.containsMatchIn(t)) return "Cancelado, ${sir()}."
            // era otra orden: el envío pendiente se descarta y se procesa lo nuevo
        }

        if (Regex("^(ayuda|que puedes hacer|comandos)\\b").containsMatchIn(t)) return help()

        val r1 = tryReply(ctx, o, low)
        if (r1 != null) return r1
        val r2 = tryOpen(ctx, t)
        if (r2 != null) return r2
        val r3 = tryRead(t)
        if (r3 != null) return r3
        val r4 = quick(ctx, t)
        if (r4 != null) return r4

        return null
    }

    private fun help(): String =
        "Puedo leer sus mensajes de WhatsApp e Instagram: «lee mis mensajes», «qué dice mamá». " +
            "Responder: «responde a mamá que ya llego», siempre con confirmación. " +
            "Llamar: «llama a Juan». Abrir apps: «abre YouTube». Alarmas y temporizadores: «temporizador de 5 minutos», «alarma a las 7». " +
            "Linterna, volumen y música: «enciende la linterna», «sube el volumen», «siguiente canción». " +
            "Navegar: «llévame a Larcomar». Y si configuró su clave de Google en Ajustes, converso y respondo cualquier pregunta."

    private fun appKey(s: String): String =
        if (s.startsWith("insta") || s == "ig") "instagram" else "whatsapp"

    private fun tryReply(ctx: Context, orig: String, low: String): String? {
        val m = replyRe.find(low.trim()) ?: return null
        val offset = low.indexOf(low.trim())
        val g = m.groups[1] ?: return null
        val start = offset + g.range.first
        val remLow = low.substring(start).trimEnd()
        val remOrig = if (orig.length == low.length) orig.substring(start).trimEnd() else remLow

        var appFilter: String? = null
        var name: String? = null
        var msgStart = 0

        val lead = leadRe.find(remLow)
        if (lead != null) {
            msgStart = lead.range.last + 1
        } else {
            var matched = false
            val sorted = Inbox.targetList().sortedByDescending { norm(it.sender).trim().length }
            for (t in sorted) {
                val ns = norm(t.sender).trim()
                if (ns.isNotEmpty() && remLow.startsWith(ns) &&
                    (remLow.length == ns.length || !remLow[ns.length].isLetterOrDigit())
                ) {
                    matched = true
                    name = t.sender
                    msgStart = ns.length
                    break
                }
            }
            if (!matched) {
                val q = splitRe.find(remLow)
                    ?: return "No entendí a quién responder, ${sir()}. Diga, por ejemplo: responde a mamá que ya llego."
                name = remOrig.substring(0, q.range.first).trim()
                msgStart = q.range.last + 1
            }
        }

        val msgLow = remLow.substring(minOf(msgStart, remLow.length))
        val msgOrig = remOrig.substring(minOf(msgStart, remOrig.length))
        val sm = stripRe.find(msgLow)
        var cut = 0
        if (sm != null) {
            cut = sm.range.last + 1
            val g1 = sm.groups[1]
            if (g1 != null) appFilter = appKey(g1.value)
        }
        val msg = msgOrig.substring(minOf(cut, msgOrig.length)).trim()

        return stageReply(ctx, name, msg, appFilter)
    }

    fun stageReply(ctx: Context, name: String?, msg: String, appFilter: String?): String {
        val target = Inbox.findTarget(name, appFilter)
        if (target == null) {
            return if (name.isNullOrBlank()) {
                "No tengo ninguna conversación reciente a la que responder, ${sir()}."
            } else {
                "No tengo una conversación abierta con $name, ${sir()}. Solo puedo responder a quien me escribió y cuya notificación sigue activa."
            }
        }
        if (msg.isBlank()) return "¿Qué mensaje le envío a ${target.sender}, ${sir()}?"

        pending = Pending { doSend(ctx, target, msg) }
        return "Voy a responder a ${target.sender} por ${target.app}: $msg. ¿Lo envío?"
    }

    private fun doSend(ctx: Context, target: ReplyTarget, text: String): String =
        if (send(ctx, target, text)) {
            "Enviado a ${target.sender} por ${target.app}, ${sir()}."
        } else {
            "No pude enviarlo. La notificación de esa conversación ya no está activa. Ábrala en ${target.app} y respóndale desde ahí."
        }

    private fun send(ctx: Context, t: ReplyTarget, text: String): Boolean {
        return try {
            val intent = Intent()
            val bundle = Bundle()
            bundle.putCharSequence(t.input.resultKey, text)
            RemoteInput.addResultsToIntent(arrayOf(t.input), intent, bundle)
            if (Build.VERSION.SDK_INT >= 28) {
                RemoteInput.setResultsSource(intent, RemoteInput.SOURCE_FREE_FORM_INPUT)
            }
            t.action.actionIntent.send(ctx, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    private fun tryOpen(ctx: Context, t: String): String? {
        val m = openRe.find(t) ?: return null
        val ig = m.groupValues[1].startsWith("insta")
        val pkg = if (ig) "com.instagram.android" else "com.whatsapp"
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return "No encuentro esa aplicación instalada, ${sir()}."
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return if (ig) "Abriendo Instagram." else "Abriendo WhatsApp."
    }

    private fun tryRead(t: String): String? {
        val m = fromRe.find(t)
        if (m != null) return readFrom(m.groupValues[1].trim())
        if (summaryRe.containsMatchIn(t)) return summary()
        return null
    }

    fun readFrom(name: String): String {
        val msg = Inbox.latestFrom(name) ?: return "No tengo mensajes de $name, ${sir()}."
        Inbox.markRead(listOf(msg))
        return "${msg.sender} dice por ${msg.app}: ${msg.text}"
    }

    fun summary(): String {
        val un = Inbox.unread()
        if (un.isEmpty()) {
            return if (!Inbox.connected) {
                "Aún no tengo acceso a sus notificaciones, ${sir()}. Concédalo en Ajustes."
            } else {
                "No tiene mensajes nuevos, ${sir()}."
            }
        }
        val bySender = un.groupBy { it.sender + "|" + it.app }
        val sb = StringBuilder()
        sb.append("Tiene ").append(un.size).append(if (un.size == 1) " mensaje nuevo. " else " mensajes nuevos. ")
        var shown = 0
        for ((_, list) in bySender) {
            if (shown >= 4) break
            val last = list.last()
            if (list.size == 1) {
                sb.append("${last.sender} por ${last.app}: ${short(last.text)}. ")
            } else {
                sb.append("${last.sender} por ${last.app}, ${list.size} mensajes, el último: ${short(last.text)}. ")
            }
            shown++
        }
        if (bySender.size > shown) sb.append("Y ${bySender.size - shown} conversaciones más.")
        Inbox.markRead(un)
        return sb.toString().trim()
    }

    private fun quick(ctx: Context, t: String): String? {
        if (Regex("\\b(que hora es|dime la hora|la hora)\\b").containsMatchIn(t)) {
            val c = Calendar.getInstance()
            return "Son las %d:%02d, %s.".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), sir())
        }
        if (Regex("\\b(que dia es|que fecha es|fecha de hoy|a cuanto estamos)\\b").containsMatchIn(t)) {
            return "Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "PE")).format(Date()) + ", ${sir()}."
        }
        if (Regex("\\b(bateria|cuanta carga)\\b").containsMatchIn(t)) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return "Batería al $pct por ciento, ${sir()}."
        }
        if (Regex("\\b(borra|elimina|limpia)\\b.*\\bmensajes\\b").containsMatchIn(t)) {
            Inbox.clear()
            return "Mensajes borrados, ${sir()}."
        }
        if (Regex("^(hola|buenas|hey|buenos dias|buenas tardes|buenas noches)\\b").containsMatchIn(t)) {
            return "A sus órdenes, ${sir()}."
        }
        if (Regex("^(gracias|muchas gracias)\\b").containsMatchIn(t)) {
            return "Para eso estoy, ${sir()}."
        }
        return null
    }
}
