package com.jarvis.asistente

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/** Servicio en primer plano: mantiene a Jarvis escuchando con la app cerrada y la pantalla apagada. */
class JarvisService : Service() {

    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == "STOP") {
            Engine.stopAlways(this)
            stopSelf()
            return START_NOT_STICKY
        }
        Engine.init(this)
        try {
            val n = buildNotif()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(11, n)
            }
        } catch (e: Exception) {
            Prefs.continuous = false
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            if (wl == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:escucha")
                w.setReferenceCounted(false)
                w.acquire()
                wl = w
            }
        } catch (e: Exception) {
        }
        Engine.beginContinuous()
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            wl?.release()
        } catch (e: Exception) {
        }
        wl = null
        Engine.endContinuous()
        super.onDestroy()
    }

    private fun buildNotif(): Notification {
        val ch = "jarvis_escucha"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Escucha de Jarvis", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stopIntent = Intent(this, JarvisService::class.java)
        stopIntent.action = "STOP"
        val stop = PendingIntent.getService(this, 1, stopIntent, flags)
        val icon = Icon.createWithResource(this, R.drawable.ic_jarvis_fg)
        return Notification.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_jarvis_fg)
            .setContentTitle("Jarvis activo")
            .setContentText("Diga «Jarvis» y su orden")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "Detener", stop).build())
            .build()
    }
}

/* ------------------------------------------------------------------ */
/*  Asistente digital del sistema (botón de inicio / encendido)        */
/* ------------------------------------------------------------------ */

class JarvisAssistService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(context, MainActivity::class.java)
        i.action = Intent.ACTION_ASSIST
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            startAssistantActivity(i)
        } catch (e: Exception) {
            try {
                context.startActivity(i)
            } catch (e2: Exception) {
            }
        }
        hide()
    }
}

/** Requisito del sistema para registrar un asistente; Jarvis usa el reconocimiento de voz de Google. */
class JarvisRecognitionStub : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (e: Exception) {
        }
    }

    override fun onCancel(listener: RecognitionService.Callback?) {}

    override fun onStopListening(listener: RecognitionService.Callback?) {}
}
