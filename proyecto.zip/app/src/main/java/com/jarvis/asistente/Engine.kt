package com.jarvis.asistente

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Motor de Jarvis: escucha, interpreta, ejecuta y responde.
 * Vive en el proceso de la app, así que sigue funcionando aunque la pantalla esté cerrada
 * cuando el servicio de escucha está activo.
 */
object Engine {

    interface Ui {
        fun onState(s: Int, partial: String?)
        fun onLine(who: String, text: String)
    }

    lateinit var app: Context
    private var ready = false
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var ui: Ui? = null

    val lines = ArrayList<Pair<String, String>>()

    /** 0 en espera, 1 escuchando, 2 pensando, 3 hablando. */
    var state = 0
        private set

    @Volatile
    var serviceRunning = false

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var manual = false
    private var errors = 0
    private var awakeUntil = 0L

    private val wake = Regex("\\b(jarvis|yarvis|harvis|jarbis|yarbis|jarves|garvis|charvis|jarvi|yarvi)\\b")

    fun init(ctx: Context) {
        if (ready) return
        app = ctx.applicationContext
        ready = true
        Speaker.init(app)
    }

    /* ------------------------------ interfaz ------------------------------- */

    fun addLine(who: String, text: String) {
        synchronized(lines) {
            lines.add(Pair(who, text))
            while (lines.size > 60) lines.removeAt(0)
        }
        ui?.onLine(who, text)
    }

    fun snapshot(): List<Pair<String, String>> {
        synchronized(lines) { return lines.toList() }
    }

    private fun setState(s: Int, partial: String? = null) {
        state = s
        ui?.onState(s, partial)
    }

    /* ----------------------- escucha siempre activa ------------------------ */

    fun startAlways(ctx: Context) {
        Prefs.continuous = true
        try {
            ctx.startForegroundService(Intent(ctx, JarvisService::class.java))
        } catch (e: Exception) {
            Prefs.continuous = false
            addLine("Jarvis", "Android no me dejó iniciar la escucha en segundo plano. Abra la app e inténtelo de nuevo.")
        }
    }

    fun stopAlways(ctx: Context) {
        Prefs.continuous = false
        try {
            ctx.stopService(Intent(ctx, JarvisService::class.java))
        } catch (e: Exception) {
        }
        endContinuous()
    }

    fun beginContinuous() {
        serviceRunning = true
        main.post {
            errors = 0
            loop()
        }
    }

    fun endContinuous() {
        serviceRunning = false
        main.post {
            cancelListening()
            setState(0)
        }
    }

    private fun loop() {
        if (!Prefs.continuous || !serviceRunning || listening || state == 2 || state == 3) return
        startListening(false)
    }

    private fun restartSoon(delay: Long = 400) {
        main.postDelayed({ loop() }, delay)
    }

    /* ------------------------------ micrófono ------------------------------ */

    fun toggleManual() {
        if (listening) {
            // ya está escuchando (modo continuo): lo siguiente que oiga cuenta como orden directa
            manual = true
        } else {
            errors = 0
            startListening(true)
        }
    }

    fun listenOnce() {
        if (!listening) {
            errors = 0
            startListening(true)
        } else {
            manual = true
        }
    }

    private fun cancelListening() {
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
        }
        listening = false
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
        listening = false
    }

    private fun startListening(isManual: Boolean) {
        if (listening) return
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addLine("Jarvis", "Me falta el permiso del micrófono. Concédalo en Ajustes.")
            if (serviceRunning) stopAlways(app)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            addLine("Jarvis", "Este teléfono no tiene reconocimiento de voz. Active o instale la app de Google.")
            return
        }
        manual = isManual
        Speaker.stop()
        try {
            val comp = app.packageManager
                .queryIntentServices(Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0)
                .map { it.serviceInfo }
                .firstOrNull { it.packageName != app.packageName }
                ?.let { android.content.ComponentName(it.packageName, it.name) }
            val r: SpeechRecognizer = recognizer ?: (
                if (comp != null) SpeechRecognizer.createSpeechRecognizer(app, comp)
                else SpeechRecognizer.createSpeechRecognizer(app)
                ).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-419")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            listening = true
            r.startListening(i)
        } catch (e: Exception) {
            destroyRecognizer()
            if (serviceRunning) restartSoon(3000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            setState(1)
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotEmpty()) setState(1, t)
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            process(t)
        }

        override fun onError(error: Int) {
            listening = false
            handleError(error)
        }
    }

    private fun handleError(error: Int) {
        setState(0)
        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
            destroyRecognizer()
        }
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            addLine("Jarvis", "Me falta el permiso del micrófono. Concédalo en Ajustes.")
            if (serviceRunning) stopAlways(app)
            return
        }
        val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
        if (serviceRunning && Prefs.continuous) {
            if (quiet) {
                errors = 0
                restartSoon(250)
            } else {
                errors++
                if (errors == 4) {
                    addLine("Jarvis", "El reconocimiento de voz está fallando (código $error). Sigo intentándolo; revise su conexión a internet.")
                }
                restartSoon(minOf(1000L * (1 shl minOf(errors, 3)), 8000L))
            }
        } else if (quiet) {
            setState(0)
        } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
            addLine("Jarvis", "Sin internet: el reconocimiento de voz de Google lo necesita. Puede escribir sus órdenes.")
        } else {
            addLine("Jarvis", "El reconocimiento de voz falló (código $error). Intente de nuevo.")
        }
    }

    /* ------------------------------- órdenes ------------------------------- */

    private fun process(text: String) {
        errors = 0
        var t = text.trim()
        if (t.isEmpty()) {
            setState(0)
            restartSoon()
            return
        }
        val now = SystemClock.elapsedRealtime()
        val open = manual || Brain.hasPending() || now < awakeUntil
        var viaWake = false
        if (!open) {
            val n = norm(t)
            val m = wake.find(n)
            if (m == null) {
                setState(0)
                restartSoon(250)
                return
            }
            viaWake = true
            val same = n.length == t.length
            val after = if (same) t.substring(m.range.last + 1) else n.substring(m.range.last + 1)
            val before = if (same) t.substring(0, m.range.first) else n.substring(0, m.range.first)
            val trimmer: (Char) -> Boolean = { it == ' ' || it == ',' || it == '.' || it == ':' || it == ';' || it == '¿' || it == '?' || it == '!' || it == '¡' }
            t = after.trim(trimmer)
            if (t.isEmpty()) t = before.trim(trimmer)
            if (t.isEmpty()) {
                addLine("Usted", "Jarvis")
                respond("Dígame, ${sir()}.", true, null)
                return
            }
        }
        submit(t, viaWake || (!manual && serviceRunning))
    }

    fun submit(text: String, keepOpen: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        addLine("Usted", t)
        val low = norm(t).replace(Regex("[¿?¡!.,;]"), " ").replace(Regex("\\s+"), " ").trim()

        if (Regex("^(callate|silencio|basta|cierra la boca)\\b").containsMatchIn(low)) {
            Speaker.stop()
            awakeUntil = 0
            setState(0)
            restartSoon()
            return
        }
        if (Regex("^(apagate|desactivate|deja de escuchar|modo descanso)\\b").containsMatchIn(low)) {
            respond("Entendido, ${sir()}. Escucha desactivada. Actívela desde la aplicación cuando me necesite.", false) {
                stopAlways(app)
            }
            return
        }
        if (Regex("^(adios|hasta luego|eso es todo|nada mas)\\b").containsMatchIn(low)) {
            awakeUntil = 0
            respond("Como ordene, ${sir()}. Aquí estaré.", false, null)
            return
        }
        if (Regex("^(olvida|borra) (la conversacion|todo lo que hablamos|el contexto)").containsMatchIn(low)) {
            Llm.clear()
            respond("Conversación reiniciada, ${sir()}.", keepOpen, null)
            return
        }

        setState(2)
        val smart = Prefs.apiKey.isNotBlank()
        val local: String? = try {
            Brain.local(app, t) ?: Device.localRoute(app, t, smart)
        } catch (e: Exception) {
            "Algo falló al ejecutar eso, ${sir()}."
        }
        if (local != null) {
            respond(local, keepOpen, null)
            return
        }
        if (!smart) {
            respond(
                "No entendí, ${sir()}. Para conversar conmigo de verdad, pegue su clave gratuita de Google en Ajustes. Mientras tanto, diga «ayuda».",
                keepOpen, null
            )
            return
        }
        Thread {
            val r = try {
                Llm.ask(app, t)
            } catch (e: Exception) {
                Llm.Result("No pude consultar mi inteligencia, ${sir()}.", emptyList())
            }
            main.post {
                var speech = r.speech
                for ((name, args) in r.actions) {
                    val act = try {
                        Device.runAction(app, name, args)
                    } catch (e: Exception) {
                        Act("No pude completar esa acción, ${sir()}.")
                    }
                    val extra = act.text
                    if (extra != null) {
                        if (act.replace) {
                            speech = extra
                            break
                        } else {
                            speech = "$speech $extra"
                        }
                    }
                }
                respond(speech, keepOpen, null)
            }
        }.start()
    }

    private fun respond(reply: String, keepOpen: Boolean, after: (() -> Unit)?) {
        addLine("Jarvis", reply)
        setState(3)
        Speaker.speak(reply) {
            if (keepOpen) awakeUntil = SystemClock.elapsedRealtime() + 7000
            setState(0)
            if (after != null) after()
            if (Brain.hasPending() && !serviceRunning) {
                main.postDelayed({ startListening(true) }, 300)
            } else {
                restartSoon()
            }
        }
    }

    /** Lee en voz alta un aviso (mensaje nuevo) pausando la escucha. */
    fun announce(text: String) {
        main.post {
            cancelListening()
            addLine("Jarvis", text)
            setState(3)
            Speaker.speak(text) {
                setState(0)
                restartSoon()
            }
        }
    }
}
