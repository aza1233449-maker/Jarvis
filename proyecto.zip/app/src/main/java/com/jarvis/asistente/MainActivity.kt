package com.jarvis.asistente

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private val BG = Color.parseColor("#050B14")
private val PANEL = Color.parseColor("#0B1B2B")
private val LINE = Color.parseColor("#1F4663")
private val CYAN = Color.parseColor("#5AD1FF")
private val GOLD = Color.parseColor("#FFB347")
private val FG = Color.parseColor("#D9EDF8")
private val MUTED = Color.parseColor("#86A3B8")

/** Orbe animado: 0 en espera, 1 escuchando, 2 procesando, 3 hablando. */
class OrbView(ctx: Context) : View(ctx) {
    var state = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 6f
        val t = SystemClock.uptimeMillis() / 1000f
        val col = if (state == 2) GOLD else CYAN
        val amp = when (state) {
            1 -> 0.10f + 0.06f * abs(sin(t * 5f))
            3 -> 0.12f + 0.12f * abs(sin(t * 9f) * sin(t * 4f))
            2 -> 0.08f
            else -> 0.03f
        }
        val rgb = col and 0x00FFFFFF

        // núcleo luminoso
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, r * (0.5f + amp),
            intArrayOf(0xFFEAFAFF.toInt(), rgb or 0xD9000000.toInt(), rgb),
            floatArrayOf(0f, 0.35f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * (0.5f + amp), p)
        p.shader = null

        p.style = Paint.Style.STROKE
        p.color = col
        p.strokeWidth = 3f
        c.drawCircle(cx, cy, r * 0.58f, p)

        // arcos giratorios
        p.strokeWidth = 6f
        p.strokeCap = Paint.Cap.ROUND
        val speed = if (state == 2) 220f else 60f
        box.set(cx - r * 0.74f, cy - r * 0.74f, cx + r * 0.74f, cy + r * 0.74f)
        for (i in 0 until 3) {
            c.drawArc(box, t * speed + i * 120f, 55f, false, p)
        }

        // marcas de reloj en el borde, girando despacio en sentido contrario
        p.strokeWidth = 2f
        p.alpha = 150
        val rot = -t * 12f
        for (i in 0 until 48) {
            val a = Math.toRadians((i * 7.5f + rot).toDouble())
            val len = if (i % 4 == 0) 0.07f else 0.035f
            val r1 = r * 0.97f
            val r2 = r * (0.97f - len)
            c.drawLine(
                cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(),
                cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), p
            )
        }
        p.alpha = 255

        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity(), Engine.Ui {

    private lateinit var mainPage: View
    private lateinit var settingsPage: View
    private lateinit var orb: OrbView
    private lateinit var statusTv: TextView
    private lateinit var accessTv: TextView
    private lateinit var chat: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var micBtn: Button
    private lateinit var alwaysSw: Switch
    private lateinit var voiceTv: TextView

    private val main = Handler(Looper.getMainLooper())
    private var syncing = false
    private var pendingAlways = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /* ----------------------------- ciclo de vida ----------------------------- */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val frame = FrameLayout(this)
        frame.setBackgroundColor(BG)
        mainPage = buildMain()
        settingsPage = buildSettings()
        settingsPage.visibility = View.GONE
        frame.addView(mainPage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(settingsPage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)

        if (Engine.snapshot().isEmpty()) {
            Engine.addLine("Jarvis", "Sistemas en línea, ${sir()}. Toque el orbe o el botón del micrófono, o escriba su orden. Diga «ayuda» para ver lo que puedo hacer.")
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Engine.ui = this
        chat.removeAllViews()
        for ((who, text) in Engine.snapshot()) addBubble(who, text)
        onState(Engine.state, null)
        updateAccess()
        syncing = true
        alwaysSw.isChecked = Prefs.continuous
        syncing = false
        if (Prefs.continuous && !Engine.serviceRunning && hasMic()) Engine.startAlways(this)
    }

    override fun onPause() {
        super.onPause()
        if (Engine.ui === this) Engine.ui = null
    }

    override fun onBackPressed() {
        if (settingsPage.visibility == View.VISIBLE) showSettings(false) else super.onBackPressed()
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_ASSIST || i.action == "android.intent.action.VOICE_COMMAND" || i.getBooleanExtra("listen", false)) {
            i.putExtra("listen", false)
            i.action = Intent.ACTION_MAIN
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            }
            main.postDelayed({ micClick() }, 500)
        }
    }

    /* ------------------------------- interfaz ------------------------------- */

    private fun label(text: String, size: Float = 14f, color: Int = FG): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(color)
        return tv
    }

    private fun section(text: String): TextView {
        val tv = label(text, 13f, CYAN)
        tv.letterSpacing = 0.15f
        tv.setPadding(0, dp(20), 0, dp(4))
        return tv
    }

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(FG)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        bg.setColor(PANEL)
        bg.setStroke(dp(1), LINE)
        b.background = bg
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        b.layoutParams = lp
        return b
    }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Engine.addLine("Jarvis", "Este teléfono no tiene esa pantalla de ajustes. Búsquela a mano en Ajustes.")
        }
    }

    private fun buildMain(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(12))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = label("J.A.R.V.I.S", 22f, CYAN)
        title.letterSpacing = 0.25f
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val settingsBtn = btn("Ajustes") { showSettings(true) }
        settingsBtn.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        top.addView(settingsBtn)
        col.addView(top)

        accessTv = label("", 12f, MUTED)
        col.addView(accessTv)

        orb = OrbView(this)
        val olp = LinearLayout.LayoutParams(dp(170), dp(170))
        olp.gravity = Gravity.CENTER_HORIZONTAL
        olp.topMargin = dp(4)
        col.addView(orb, olp)
        orb.setOnClickListener { micClick() }

        statusTv = label("En espera", 13f, CYAN)
        statusTv.gravity = Gravity.CENTER_HORIZONTAL
        statusTv.letterSpacing = 0.1f
        col.addView(statusTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        alwaysSw = Switch(this)
        alwaysSw.text = "Modo siempre activo (escucha con la app cerrada)"
        alwaysSw.setTextColor(FG)
        alwaysSw.textSize = 13f
        alwaysSw.setOnCheckedChangeListener { _, on ->
            if (!syncing) {
                if (on) {
                    if (hasMic()) {
                        Engine.startAlways(this)
                    } else {
                        pendingAlways = true
                        requestPerms()
                        syncing = true
                        alwaysSw.isChecked = false
                        syncing = false
                    }
                } else {
                    Engine.stopAlways(this)
                }
            }
        }
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(6)
        col.addView(alwaysSw, slp)

        chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        chatScroll = ScrollView(this)
        chatScroll.addView(chat)
        val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        llp.topMargin = dp(6)
        col.addView(chatScroll, llp)

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val sugg = listOf(
            "Mis mensajes" to "lee mis mensajes",
            "Hora" to "qué hora es",
            "Linterna" to "enciende la linterna",
            "Temporizador" to "temporizador de 5 minutos",
            "Batería" to "cuánta batería tengo",
            "Ayuda" to "ayuda"
        )
        for ((chipText, cmd) in sugg) {
            val chip = label(chipText, 13f, CYAN)
            chip.setPadding(dp(14), dp(7), dp(14), dp(7))
            val bg = GradientDrawable()
            bg.cornerRadius = dp(20).toFloat()
            bg.setColor(PANEL)
            bg.setStroke(dp(1), LINE)
            chip.background = bg
            chip.setOnClickListener { Engine.submit(cmd) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            chips.addView(chip, lp)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.topMargin = dp(8)
        col.addView(hs, hlp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Escriba su orden"
        input.setHintTextColor(MUTED)
        input.setTextColor(FG)
        input.setSingleLine(true)
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val send = btn("Enviar") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                input.setText("")
                Engine.submit(t)
            }
        }
        send.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        row.addView(send)
        col.addView(row)

        micBtn = btn("Hablar") { micClick() }
        col.addView(micBtn)
        return col
    }

    private fun addBubble(who: String, text: String) {
        val mine = who == "Usted"
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 15f
        tv.setTextColor(FG)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(if (mine) Color.parseColor("#12324A") else PANEL)
        bg.setStroke(dp(1), if (mine) CYAN else LINE)
        tv.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.topMargin = dp(6)
        chat.addView(tv, lp)
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun buildSettings(): View {
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(32))
        sv.addView(col)

        col.addView(btn("← Volver") { showSettings(false) })

        // --- inteligencia ---
        col.addView(section("INTELIGENCIA ARTIFICIAL"))
        col.addView(
            label(
                "Con una clave gratuita de Google (Gemini) converso de verdad, respondo preguntas y entiendo órdenes con sus propias palabras. " +
                    "Sin clave solo entiendo órdenes fijas.",
                12f, MUTED
            )
        )
        col.addView(btn("1. Conseguir mi clave gratis") {
            safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        })
        val key = EditText(this)
        key.hint = "2. Pegue aquí su clave (empieza con AIza)"
        key.setHintTextColor(MUTED)
        key.setTextColor(FG)
        key.setSingleLine(true)
        key.setText(Prefs.apiKey)
        key.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.apiKey = s?.toString()?.trim().orEmpty()
            }
        })
        col.addView(key)
        col.addView(label("Modelo (déjelo así salvo que falle):", 12f, MUTED))
        val model = EditText(this)
        model.setTextColor(FG)
        model.setSingleLine(true)
        model.setText(Prefs.model)
        model.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.trim().orEmpty()
                if (v.isNotEmpty()) Prefs.model = v
            }
        })
        col.addView(model)
        col.addView(btn("3. Probar mi inteligencia") {
            showSettings(false)
            Engine.submit("Preséntate en una frase corta")
        })

        // --- permisos ---
        col.addView(section("PERMISOS (HÁGALOS EN ORDEN)"))
        col.addView(btn("1. Micrófono, contactos, llamadas, SMS y avisos") { requestPerms() })
        col.addView(btn("2. Acceso a notificaciones (leer WhatsApp e Instagram)") {
            safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("   Si está bloqueado: permitir ajustes restringidos") {
            safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(btn("3. Mostrar sobre otras apps (para abrir apps con la pantalla apagada)") {
            safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("4. Batería: sin restricciones") {
            safeStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(btn("5. Hacer de Jarvis mi asistente (botón de inicio o encendido)") {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (e: Exception) {
                safeStart(Intent("android.settings.VOICE_INPUT_SETTINGS"))
            }
        })

        // --- nombre ---
        col.addView(section("SU NOMBRE"))
        val name = EditText(this)
        name.hint = "Cómo debo llamarle (por defecto, señor)"
        name.setHintTextColor(MUTED)
        name.setTextColor(FG)
        name.setSingleLine(true)
        name.setText(Prefs.userName)
        name.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.userName = s?.toString()?.trim().orEmpty()
            }
        })
        col.addView(name)

        // --- comportamiento ---
        col.addView(section("COMPORTAMIENTO"))
        val announceSw = Switch(this)
        announceSw.text = "Leer en voz alta los mensajes nuevos"
        announceSw.setTextColor(FG)
        announceSw.isChecked = Prefs.announce
        announceSw.setOnCheckedChangeListener { _, checked -> Prefs.announce = checked }
        col.addView(announceSw)

        // --- voz ---
        col.addView(section("VOZ"))
        voiceTv = label("Voz automática (se prefiere masculina en español latino)", 12f, MUTED)
        col.addView(voiceTv)
        col.addView(btn("Probar otra voz") {
            val v = Speaker.nextVoice()
            if (v.isEmpty()) {
                voiceTv.text = "No hay voces en español instaladas. En Ajustes del teléfono, Salida de texto a voz, instale datos de voz en español."
            } else {
                voiceTv.text = "Voz: $v"
                Speaker.speak("A sus órdenes, ${sir()}.", null)
            }
        })
        col.addView(label("Tono", 13f, FG))
        val pitchBar = SeekBar(this)
        pitchBar.max = 100
        pitchBar.progress = ((Prefs.pitch - 0.4f) / 0.012f).toInt().coerceIn(0, 100)
        pitchBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) Prefs.pitch = 0.4f + progress * 0.012f
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                Speaker.speak("A sus órdenes, ${sir()}.", null)
            }
        })
        col.addView(pitchBar)
        col.addView(label("Velocidad", 13f, FG))
        val rateBar = SeekBar(this)
        rateBar.max = 100
        rateBar.progress = ((Prefs.rate - 0.7f) / 0.006f).toInt().coerceIn(0, 100)
        rateBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) Prefs.rate = 0.7f + progress * 0.006f
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                Speaker.speak("A sus órdenes, ${sir()}.", null)
            }
        })
        col.addView(rateBar)

        // --- privacidad ---
        col.addView(section("PRIVACIDAD"))
        col.addView(
            label(
                "Los mensajes de WhatsApp e Instagram solo se guardan en la memoria del teléfono y nunca se envían a la IA. " +
                    "Lo que sale del teléfono: el audio de su voz (lo procesa el reconocimiento de voz de Google) y, si usó su clave, el texto de lo que me dice a mí (se envía a Google Gemini). " +
                    "Con el modo siempre activo el micrófono permanece abierto y consume batería.",
                12f, MUTED
            )
        )
        return sv
    }

    private fun showSettings(show: Boolean) {
        settingsPage.visibility = if (show) View.VISIBLE else View.GONE
        mainPage.visibility = if (show) View.GONE else View.VISIBLE
        if (!show) updateAccess()
    }

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun updateAccess() {
        val on = listenerEnabled()
        val ia = if (Prefs.apiKey.isNotBlank()) "IA: ACTIVA" else "IA: sin clave"
        if (on) {
            accessTv.text = "Mensajes: ACTIVO · ${Inbox.total()} en memoria · $ia"
            accessTv.setTextColor(CYAN)
            if (!Inbox.connected) {
                try {
                    NotificationListenerService.requestRebind(ComponentName(this, NotificationService::class.java))
                } catch (e: Exception) {
                }
            }
        } else {
            accessTv.text = "Mensajes: falta el acceso a notificaciones (Ajustes, paso 2) · $ia"
            accessTv.setTextColor(GOLD)
        }
    }

    /* --------------------------------- voz --------------------------------- */

    private fun hasMic(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.READ_CONTACTS)
        list.add(Manifest.permission.CALL_PHONE)
        list.add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) list.add("android.permission.POST_NOTIFICATIONS")
        requestPermissions(list.toTypedArray(), 7)
    }

    private fun micClick() {
        if (!hasMic()) {
            requestPerms()
            return
        }
        Engine.toggleManual()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasMic()) {
            if (pendingAlways) {
                pendingAlways = false
                Engine.startAlways(this)
                syncing = true
                alwaysSw.isChecked = true
                syncing = false
            }
        } else {
            Engine.addLine("Jarvis", "Sin permiso de micrófono no puedo escucharle. Puede escribir sus órdenes.")
        }
    }

    /* ---------------------------- Engine.Ui ---------------------------- */

    override fun onState(s: Int, partial: String?) {
        orb.state = s
        statusTv.setTextColor(if (s == 2) GOLD else CYAN)
        statusTv.text = when (s) {
            1 -> if (partial != null) "…$partial" else "ESCUCHANDO"
            2 -> "PROCESANDO"
            3 -> "HABLANDO"
            else -> if (Engine.serviceRunning) "En espera · diga «Jarvis»" else "En espera"
        }
        micBtn.text = if (s == 1) "Escuchando… (toque para dirigirme la orden)" else "Hablar"
    }

    override fun onLine(who: String, text: String) {
        addBubble(who, text)
    }
}
