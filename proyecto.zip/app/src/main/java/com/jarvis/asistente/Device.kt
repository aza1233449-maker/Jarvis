package com.jarvis.asistente

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject

/** Resultado de una acción: texto a decir (o null si salió bien) y si reemplaza la frase de la IA. */
class Act(val text: String?, val replace: Boolean = false)

class Contact(val name: String, val number: String)

/** Acciones sobre el teléfono. */
object Device {

    private fun go(ctx: Context, i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun hasPerm(ctx: Context, p: String): Boolean =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /* ------------------------------ ejecución ------------------------------ */

    fun runAction(ctx: Context, name: String, a: JSONObject): Act {
        return when (name) {
            "flashlight" -> Act(flashlight(ctx, a.optBoolean("on", true)))
            "volume" -> Act(volume(ctx, a))
            "media" -> Act(media(ctx, a.optString("cmd")))
            "timer" -> Act(timer(ctx, a.optInt("seconds", 0), a.optString("label")))
            "alarm" -> Act(alarm(ctx, a.optInt("hour", -1), a.optInt("minute", 0), a.optString("label")))
            "call" -> Act(call(ctx, a.optString("name"), a.optString("number")))
            "whatsapp_message" -> Act(whatsapp(ctx, a.optString("name"), a.optString("number"), a.optString("text")))
            "open_app" -> Act(openApp(ctx, a.optString("name")))
            "navigate" -> Act(navigate(ctx, a.optString("query")))
            "search" -> Act(search(ctx, a.optString("query")))
            "youtube" -> Act(youtube(ctx, a.optString("query")))
            "spotify" -> Act(spotify(ctx, a.optString("query")))
            "settings" -> Act(settings(ctx, a.optString("target")))
            "read_messages" -> {
                val who = a.optString("name")
                Act(if (who.isBlank()) Brain.summary() else Brain.readFrom(who), true)
            }
            "reply_message" -> {
                val who = a.optString("name")
                val app = a.optString("app")
                Act(
                    Brain.stageReply(
                        ctx,
                        if (who.isBlank()) null else who,
                        a.optString("text"),
                        if (app.isBlank()) null else norm(app)
                    ),
                    true
                )
            }
            "sms" -> smsStage(ctx, a)
            else -> Act("No sé hacer eso todavía, ${sir()}.")
        }
    }

    /* ------------------------------ acciones ------------------------------- */

    fun flashlight(ctx: Context, on: Boolean): String? {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(cid)
                if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                "Este teléfono no tiene linterna disponible."
            } else {
                cm.setTorchMode(id, on)
                null
            }
        } catch (e: Exception) {
            "No pude controlar la linterna."
        }
    }

    fun volume(ctx: Context, a: JSONObject): String? {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val st = AudioManager.STREAM_MUSIC
            val max = am.getStreamMaxVolume(st)
            if (a.has("percent")) {
                val p = a.optInt("percent", 50).coerceIn(0, 100)
                am.setStreamVolume(st, (max * p) / 100, AudioManager.FLAG_SHOW_UI)
                null
            } else {
                when (a.optString("dir")) {
                    "up" -> {
                        am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                        am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, 0)
                        null
                    }
                    "down" -> {
                        am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                        am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, 0)
                        null
                    }
                    "mute" -> {
                        am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                        null
                    }
                    "unmute" -> {
                        am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                        null
                    }
                    "max" -> {
                        am.setStreamVolume(st, max, AudioManager.FLAG_SHOW_UI)
                        null
                    }
                    else -> "No entendí qué hacer con el volumen."
                }
            }
        } catch (e: Exception) {
            "No pude cambiar el volumen."
        }
    }

    fun media(ctx: Context, cmd: String): String? {
        val code = when (cmd) {
            "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return "No entendí ese control de música."
        }
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            null
        } catch (e: Exception) {
            "No pude controlar la música."
        }
    }

    fun timer(ctx: Context, seconds: Int, label: String): String? {
        if (seconds <= 0) return "No entendí la duración del temporizador."
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
        i.putExtra(AlarmClock.EXTRA_LENGTH, seconds)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return if (go(ctx, i)) null else "No encontré una aplicación de reloj para el temporizador."
    }

    fun alarm(ctx: Context, hour: Int, minute: Int, label: String): String? {
        if (hour !in 0..23 || minute !in 0..59) return "No entendí la hora de la alarma."
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
        i.putExtra(AlarmClock.EXTRA_HOUR, hour)
        i.putExtra(AlarmClock.EXTRA_MINUTES, minute)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return if (go(ctx, i)) null else "No encontré una aplicación de reloj para la alarma."
    }

    /* ------------------------------ contactos ------------------------------ */

    fun findContact(ctx: Context, query: String): Contact? {
        if (!hasPerm(ctx, Manifest.permission.READ_CONTACTS)) return null
        val q = norm(query).trim()
        if (q.isEmpty()) return null
        var best: Contact? = null
        var bestScore = 0
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return null
        c.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                val nn = norm(n).trim()
                val s = when {
                    nn == q -> 4
                    nn.startsWith(q) -> 3
                    nn.split(" ").any { w -> w == q } -> 2
                    nn.contains(q) -> 1
                    else -> 0
                }
                if (s > bestScore) {
                    bestScore = s
                    best = Contact(n, num)
                }
            }
        }
        return best
    }

    private fun contactFor(ctx: Context, name: String, number: String): Contact? {
        val digits = number.filter { it.isDigit() }
        if (digits.length >= 3) return Contact(if (name.isBlank()) number else name, number)
        return findContact(ctx, name)
    }

    private fun noContact(ctx: Context, name: String): String =
        if (!hasPerm(ctx, Manifest.permission.READ_CONTACTS)) {
            "Necesito permiso para leer sus contactos, ${sir()}. Concédalo en Ajustes."
        } else {
            "No encuentro a $name en sus contactos, ${sir()}."
        }

    fun call(ctx: Context, name: String, number: String): String? {
        val ct = contactFor(ctx, name, number) ?: return noContact(ctx, name)
        val direct = hasPerm(ctx, Manifest.permission.CALL_PHONE)
        val i = Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(ct.number)))
        return if (go(ctx, i)) null else "No pude iniciar la llamada."
    }

    private fun smsStage(ctx: Context, a: JSONObject): Act {
        val text = a.optString("text")
        val ct = contactFor(ctx, a.optString("name"), a.optString("number"))
            ?: return Act(noContact(ctx, a.optString("name")), true)
        if (text.isBlank()) return Act("¿Qué mensaje le envío a ${ct.name}, ${sir()}?", true)
        val q = Brain.confirm("Voy a enviar un SMS a ${ct.name}: $text.") { sendSms(ctx, ct.number, text) }
        return Act(q, true)
    }

    @Suppress("DEPRECATION")
    fun sendSms(ctx: Context, number: String, text: String): String {
        if (!hasPerm(ctx, Manifest.permission.SEND_SMS)) return "Necesito el permiso de SMS, ${sir()}. Concédalo en Ajustes."
        return try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null)
            "SMS enviado, ${sir()}."
        } catch (e: Exception) {
            "No pude enviar el SMS."
        }
    }

    fun whatsapp(ctx: Context, name: String, number: String, text: String): String? {
        val ct = contactFor(ctx, name, number) ?: return noContact(ctx, name)
        var d = ct.number.filter { it.isDigit() }
        // Números locales de Perú de 9 dígitos: se les antepone el código de país.
        if (d.length == 9 && d.startsWith("9")) d = "51$d"
        var url = "https://wa.me/$d"
        if (text.isNotBlank()) url += "?text=" + Uri.encode(text)
        return if (go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) null else "No pude abrir WhatsApp."
    }

    /* ---------------------------- aplicaciones ----------------------------- */

    private val aliases = mapOf(
        "wasap" to "whatsapp", "wsp" to "whatsapp", "guasap" to "whatsapp",
        "insta" to "instagram", "face" to "facebook", "yt" to "youtube",
        "mapas" to "maps", "camara" to "camara", "ajustes" to "ajustes"
    )

    fun openApp(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        var q = norm(name).trim()
        if (q.isEmpty()) return "No entendí qué aplicación abrir, ${sir()}."
        q = aliases[q] ?: q
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        var best: String? = null
        var score = 0
        for (ri in list) {
            val label = norm(ri.loadLabel(pm).toString()).trim()
            val s = when {
                label == q -> 4
                label.startsWith(q) -> 3
                label.contains(q) -> 2
                label.length > 3 && q.contains(label) -> 1
                else -> 0
            }
            if (s > score) {
                score = s
                best = ri.activityInfo.packageName
            }
        }
        val pkg = best ?: return "No encuentro una aplicación llamada $name, ${sir()}."
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "No pude abrir $name."
        return if (go(ctx, i)) null else "No pude abrir $name."
    }

    fun navigate(ctx: Context, query: String): String? {
        if (query.isBlank()) return "No entendí el destino, ${sir()}."
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(query)))
        i.setPackage("com.google.android.apps.maps")
        if (go(ctx, i)) return null
        val j = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query)))
        return if (go(ctx, j)) null else "No encontré una aplicación de mapas."
    }

    fun search(ctx: Context, query: String): String? {
        if (query.isBlank()) return "No entendí qué buscar, ${sir()}."
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
        return if (go(ctx, i)) null else "No pude abrir el navegador."
    }

    fun youtube(ctx: Context, query: String): String? {
        if (query.isBlank()) return "No entendí qué buscar en YouTube, ${sir()}."
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
        return if (go(ctx, i)) null else "No pude abrir YouTube."
    }

    fun spotify(ctx: Context, query: String): String? {
        if (query.isBlank()) return "No entendí qué buscar en Spotify, ${sir()}."
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(query)))
        i.setPackage("com.spotify.music")
        if (go(ctx, i)) return null
        val j = Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/" + Uri.encode(query)))
        return if (go(ctx, j)) null else "No pude abrir Spotify."
    }

    fun settings(ctx: Context, target: String): String? {
        val action = when (target) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (go(ctx, Intent(action))) null else "No pude abrir los ajustes."
    }

    /* ------------------- órdenes sin IA (reglas sencillas) ------------------- */

    private fun clean(s: String): String =
        norm(s).replace(Regex("[¿?¡!.,;]"), " ").replace(Regex("\\s+"), " ").trim()

    fun localRoute(ctx: Context, orig: String, smart: Boolean): String? {
        val t = clean(orig)
        if (t.isEmpty()) return null

        // linterna
        if (Regex("\\blinterna\\b").containsMatchIn(t)) {
            val off = Regex("\\b(apaga|apagar|apagame|desactiva|quita|cierra)\\b").containsMatchIn(t)
            val e = flashlight(ctx, !off)
            return e ?: if (off) "Linterna apagada, ${sir()}." else "Linterna encendida, ${sir()}."
        }

        // volumen
        if (Regex("\\bvolumen\\b").containsMatchIn(t)) {
            val n = Regex("\\b(\\d{1,3})\\b").find(t)
            val a = JSONObject()
            when {
                Regex("\\b(maximo|al maximo|a tope)\\b").containsMatchIn(t) -> a.put("dir", "max")
                Regex("\\b(silencia|silenciar|mute|apaga|quita)\\b").containsMatchIn(t) -> a.put("dir", "mute")
                n != null -> a.put("percent", n.groupValues[1].toInt())
                Regex("\\b(sube|subir|aumenta|aumentar|mas alto|arriba)\\b").containsMatchIn(t) -> a.put("dir", "up")
                Regex("\\b(baja|bajar|disminuye|reduce|mas bajo|abajo)\\b").containsMatchIn(t) -> a.put("dir", "down")
                else -> return null
            }
            return volume(ctx, a) ?: "Listo, ${sir()}."
        }

        // música
        if (Regex("^(pausa|pausar|pon pausa|pausa la musica|pausa la cancion|detén la musica|detene la musica|para la musica)\\b").containsMatchIn(t)) {
            return media(ctx, "play_pause") ?: "Música en pausa, ${sir()}."
        }
        if (Regex("^(reanuda|reanudar|continua la musica|dale play|reproduce la musica|sigue la musica|continua con la musica)\\b").containsMatchIn(t)) {
            return media(ctx, "play_pause") ?: "Reanudando, ${sir()}."
        }
        if (Regex("\\b(siguiente|proxima|salta|pasa)\\b.*\\b(cancion|tema|musica|pista)\\b").containsMatchIn(t)) {
            return media(ctx, "next") ?: "Siguiente canción."
        }
        if (Regex("\\b(anterior|regresa|vuelve)\\b.*\\b(cancion|tema|pista)\\b").containsMatchIn(t)) {
            return media(ctx, "previous") ?: "Canción anterior."
        }

        // temporizador
        val tm = Regex("\\b(?:temporizador|cronometro|timer|avisame|despiertame)\\b.*?\\b(?:de|por|en|a)?\\s*(\\d+|un|una|medio|media)\\s*(segundos?|minutos?|horas?)\\b").find(t)
        if (tm != null && !Regex("\\balarma\\b").containsMatchIn(t)) {
            val raw = tm.groupValues[1]
            val unit = tm.groupValues[2]
            val qty = when (raw) {
                "un", "una" -> 1.0
                "medio", "media" -> 0.5
                else -> raw.toDouble()
            }
            val mult = when {
                unit.startsWith("seg") -> 1
                unit.startsWith("min") -> 60
                else -> 3600
            }
            val secs = (qty * mult).toInt()
            return timer(ctx, secs, "") ?: "Temporizador de ${tm.groupValues[1]} ${unit}, ${sir()}."
        }

        // alarma
        if (Regex("\\b(alarma|despiertame)\\b").containsMatchIn(t) && !Regex("\\b(borra|elimina|cancela|quita)\\b").containsMatchIn(t)) {
            val am = Regex("\\b(\\d{1,2})(?:[: ](\\d{2}))?\\s*(am|pm|a m|p m|de la manana|de la tarde|de la noche|de la madrugada)?\\b").find(t)
            if (am != null) {
                var h = am.groupValues[1].toInt()
                val min = if (am.groupValues[2].isEmpty()) 0 else am.groupValues[2].toInt()
                val suf = am.groupValues[3]
                val pm = suf.startsWith("p") || suf.contains("tarde") || suf.contains("noche")
                if (pm && h < 12) h += 12
                if (!pm && suf.isNotEmpty() && h == 12) h = 0
                return alarm(ctx, h, min, "") ?: "Alarma programada a las %d:%02d, %s.".format(h, min, sir())
            }
        }

        // llamar
        val cm = Regex("^(?:llama|llamar|llamame|marca|telefonea|haz una llamada)\\s+(?:a\\s+)?(.+)$").find(t)
        if (cm != null) {
            val who = cm.groupValues[1].trim()
            return call(ctx, who, "") ?: "Llamando a $who, ${sir()}."
        }

        // navegar
        val nm = Regex("^(?:llevame a|navega a|navegar a|como llego a|ruta a|indicaciones a|direcciones a|guiame a)\\s+(.+)$").find(t)
        if (nm != null) {
            val dest = nm.groupValues[1].trim()
            return navigate(ctx, dest) ?: "Calculando la ruta a $dest, ${sir()}."
        }

        // YouTube / Spotify
        val yt = Regex("^(?:pon|ponme|reproduce|busca|buscame)\\s+(.+?)\\s+en\\s+youtube$").find(t)
            ?: Regex("^(?:busca en youtube|youtube)\\s+(.+)$").find(t)
        if (yt != null) {
            val q = yt.groupValues[1].trim()
            return youtube(ctx, q) ?: "Buscando $q en YouTube."
        }
        val sp = Regex("^(?:pon|ponme|reproduce|busca|buscame)\\s+(.+?)\\s+en\\s+spotify$").find(t)
        if (sp != null) {
            val q = sp.groupValues[1].trim()
            return spotify(ctx, q) ?: "Buscando $q en Spotify."
        }

        // ajustes del sistema
        val st = Regex("^(?:abre|abrir|abreme|ve a|ajustes de|configura)\\s+.*\\b(wifi|wi fi|bluetooth|bateria|ubicacion|sonido|pantalla)\\b").find(t)
        if (st != null) {
            val target = when (st.groupValues[1]) {
                "wifi", "wi fi" -> "wifi"
                "bluetooth" -> "bluetooth"
                "bateria" -> "battery"
                "ubicacion" -> "location"
                "sonido" -> "sound"
                else -> "display"
            }
            return settings(ctx, target) ?: "Abriendo los ajustes, ${sir()}."
        }

        // abrir aplicaciones
        val op = Regex("^(?:abre|abrir|abreme|lanza|inicia|ejecuta)\\s+(?:el |la |mi |los |las )?(?:app de |aplicacion de |aplicacion |app )?(.+)$").find(t)
        if (op != null) {
            val app = op.groupValues[1].trim()
            return openApp(ctx, app) ?: "Abriendo $app, ${sir()}."
        }

        // búsqueda web (solo sin IA; con IA la respuesta es hablada)
        if (!smart) {
            val sm = Regex("^(?:busca|buscame|googlea|investiga|busca en google)\\s+(.+)$").find(t)
            if (sm != null) {
                val q = sm.groupValues[1].trim()
                return search(ctx, q) ?: "Buscando $q, ${sir()}."
            }
        }
        return null
    }
}
